import os
import matplotlib.pyplot as plt
import numpy as np
import matplotlib.gridspec as gridspec
from io import StringIO
# import pandas as pd
import csv


                ########## Graph Dimensions ##############

# User should select the dimensions of the plots.

# User enter the no of rows, which they want.
rows = int(input("How many rows you want: ", ))

# User enter the number, how many plots are in parallel or in a each row.
cols = int(input("How many plots for each rows: ", ))

print("User should upload "+ str(rows * cols) + " input files!")
print("User will get "+ str(rows * cols) + " no of plots!")


            #######  Graph Type #########

# User needs to select the graph type, from the following options
print("graph types: 1:gyration , 2:rmsf, 3:protein rmsd, 4:ligand rmsd, 5:hbond")

# User should enter the number based on their graph choice
graph_type = input("Enter the graph type number : ")


########### Graph Labels ###########

# global variables used across the script
title = ''
xlabel = ''
ylabel = ''

#Based on the graph type number, plot labels are assigned
if graph_type == "1":
    title = "Radius of Gyration"
    xlabel = "Time (ps)"
    ylabel = "Radius of Gyration (nm)"
elif graph_type == "2":
    title = "RMSF Graph"
    xlabel = "Residue number (ns)"
    ylabel = "RMSF (nm)"
elif graph_type == "3":
    title = "RMSD Graph"
    xlabel = "Time (ns)"
    ylabel = "Protein backbone RMSD (nm)"
elif graph_type == "4":
    title = "RMSD Graph"
    xlabel = "Time (ns)"
    ylabel = "Ligand RMSD (nm)"
elif graph_type == "5":
    title = "H Bonds Graph"
    xlabel = "Time (ps)"
    ylabel = "Number of H-bonds"



################ Output file Prefix ###############

outputfile_prefix = input("Enter the outputfile prefix : ")

# Subplots dimension and figure size
# User needs to the set the plot dimensions, based on the dimensions, to handle the input files
fig, axis = plt.subplots(rows,cols, figsize = (30,27), squeeze=False)


              ################ File Parser ##############

# Handler to read the file and returns the array data (np array)
def xvg_data_parser(input_file):
    with open(input_file, 'r') as infile:
        data = []
        lines = infile.readlines()
        for line in lines:
            if line.startswith('#') or line.startswith('@'):
                continue
            data.append(line)
        result = "".join(data)
        array = np.genfromtxt(StringIO(result))
        return array

                      ############ plot the Graph ####################

# storing x and y data for each graph and writing into the csv file
csvx_data = []
csvy_data = []

# file names
labels = []
labels.append(xlabel)

# Handling the plots
for r in range(rows):
    for c in range(cols):
        infile = input("Enter the input file: ")
        if infile != "":
            if os.path.isfile(infile):
                data = xvg_data_parser(infile)
                x_data = data[:,0]
                # print("x: ",len(x_data))
                csvx_data.append(x_data)
                y_data = data[:,1]
                # print("y: ",len(y_data))
                csvy_data.append(y_data)
                x_data_minlim = x_data[0]
                x_data_maxlim = x_data[-1]
                label = infile.replace(".xvg", "")
                labels.append(label)
                print(labels)
                axis[r, c].plot(x_data, y_data, color = "black")
                axis[r, c].set_xlim(0, x_data_maxlim)
                axis[r, c].legend(loc = 'lower center', frameon = False, ncol = 3, fontsize = 20)
                axis[r, c].set_title(label, loc = 'center', fontsize = 20, fontweight="bold")
                axis[r, c].xaxis.set_tick_params(width=4, direction="in", length=4)
                axis[r, c].yaxis.set_tick_params(width=4, direction="in", length=4)
                axis[r, c].tick_params(axis='both', labelsize=20)
                axis[r, c].set_xlabel(xlabel, fontsize = 20)
                axis[r, c].set_ylabel(ylabel, fontsize = 20)
            else:
                print(infile + "not found!")
        else:
            axis[r, c].remove()



              #########################  csv file writing #####################

plot_data = []
plot_data.append(csvx_data[1])
plot_data.extend(csvy_data)

with open(outputfile_prefix+".csv", "w", newline = "") as outfile:
    writer = csv.DictWriter(outfile, fieldnames=labels)
    writer.writeheader()
    for i in range(len(csvx_data[1])):
        d = {}
        for ind, col in enumerate(plot_data):
            d.update({labels[ind] : col[i]})
        writer.writerow(d)



                ########################### plot #############################
## User can show plots without writing into the file
# plt.show()

# User can modify the plot Title here
fig.suptitle(title, fontsize = 20, fontweight="bold")


# write the plots to the file
plt.savefig(outputfile_prefix + ".png", dpi =300, format='jpeg', pil_kwargs={'optimize':True, 'quality':80})# save and quality params

